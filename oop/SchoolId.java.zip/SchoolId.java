package com.learning.oop;

import java.util.Scanner;

public class SchoolId {
    public static void main(String[] args) {

        String name;
        int age;
        String bloodGroup;


        Scanner scanner = new Scanner(System.in);
       // System.out.println(" Enter your name");

        name = scanner.next();
        System.out.println(" Name: " + name);

        //System.out.println(" Enter your age");
        age = scanner.nextInt();
        System.out.println(" Age: " + age);
        //System.out.println(" Enter your blood group");
        bloodGroup = scanner.next();

        boolean Red = true;
        boolean Blue = true;
        boolean Yellow = true;
        String Id = null;
        if( age>=20) {
            Id = "Red Group";
        }else if ((age<20)&&(age>=15)){
            Id = "Blue Group";
        }
        else if ((age<15)&& (age>=10)){
            Id = "Yellow Group";
        }
        scanner.close();
        System.out.println("Name: " + name );
        System.out.println(" Age: " + age );
        System.out.println(" Blood group: " +  bloodGroup);
        System.out.println("---------------------------------------------");
        System.out.println(" Your group is " + Id);
        System.out.println("---------------------------------------------");
    }

}
